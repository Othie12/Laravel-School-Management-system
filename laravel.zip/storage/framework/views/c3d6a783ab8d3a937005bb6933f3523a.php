<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['name', 'value' => null]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['name', 'value' => null]); ?>
<?php foreach (array_filter((['name', 'value' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $attributes = $attributes->class([
        'form-checkbox',
        'text-indigo-600' => old($name, $attributes['value'] ?? $value) == $value,
    ]);
?>

<input
    type="checkbox"
    <?php echo e($attributes->merge(['name' => $name, 'id' => $name])); ?>

    <?php echo e($attributes->has('value') ? 'value="'.$value.'"' : ''); ?>

    <?php echo e(old($name) ? 'checked' : ''); ?>

><?php /**PATH /opt/lampp/htdocs/todo-app/resources/views/components/checkbox.blade.php ENDPATH**/ ?>