<?php $__env->startSection('content'); ?>

<div class="jumbotron" align="center">
    <h1>Hello <?php echo e(Auth::user()->sex === 'm'? 'Sir.' : 'Madam.'); ?></h1>
    <?php if($period != null): ?>
        <h2 class="text-info"><?php echo e($period->name); ?> <br><span class="badge badge-info"><?php echo e(str_replace('-', '/', $period->date_from)); ?> to <?php echo e(str_replace('-', '/', $period->date_to)); ?></span></h2>
    <?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')  ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status')  )]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
</div>

<?php if(Auth::user()->role === 'head_teacher'): ?>
<div class="btn-group" align="left" style="position: sticky; top: 20%; z-index:1;">
    <button class="btn btn-danger">Set Headteacher's comments here</button>
    <button class="btn btn-danger dropdown-toggle" data-toggle="dropdown">
        <span class="caret"></span>
    </button>
    <ul class="dropdown-menu" style="z-index:1;">
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($class->comments) > 0): ?>
                <li><a href="<?php echo e(route('comments.edit', ['class_id' => $class->id])); ?>"><?php echo e($class->name); ?></a></li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<?php if(in_array(Auth::user()->role, ['admini', 'head_teacher'])): ?>
    <div class="btn-group" align="left" style="position: sticky; top: 20%; z-index:1;">
        <button class="btn btn-danger">Set School Fees</button>
            <button class="btn btn-danger dropdown-toggle" data-toggle="dropdown">
                <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" style="z-index:1;">
                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('requirements.schoolfees', ['class_id' => $class->id])); ?>"><?php echo e($class->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
    </div>
<?php endif; ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/todo-app/resources/views/dashboard.blade.php ENDPATH**/ ?>