<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="tabbable tabs-left">
        <ul class="nav nav-tabs flex justify-between">
            <li><a href="#tab1" data-toggle="tab"><button type="button" class="btn btn-primary" style="background-color: deepskyblue"> Marksheet </button></a></li>
            <li><a href="#tab2" data-toggle="tab"><button type="button" class="btn btn-primary active" style="background-color: deepskyblue"> Students </button></a></li>
            <li><a href="#tab3" data-toggle="tab"><button type="button" class="btn btn-primary" style="background-color: deepskyblue"> Requirements </button></a></li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane" id="tab1">
                <table class="table table-hover table-stripes">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <?php $__currentLoopData = $class->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th> <?php echo e($subject->name); ?> </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $class->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($student->name); ?> </td>
                            <?php $__currentLoopData = $class->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $mark = $subject->marks()->where('student_id', $student->id)->where('type', 'end')->orderBy('created_at', 'desc')->first() ?>
                                <th class="<?php echo e($mark ? '' : 'text-danger'); ?>"> <?php echo e($mark ? $mark->mark  : 'Not set'); ?>  </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Auth::user()->class === $student->class): ?>
                                <td>
                                    <form action="<?php echo e($student->already_promoted() ? route('student.demote', ['id' => $student->id]) : route('student.promote', ['id' => $student->id])); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('patch'); ?>
                                        <button class="btn <?php echo e($student->already_promoted() ? 'btn-danger' : 'btn-info'); ?>"><?php echo e($student->already_promoted() ? 'Demote' : 'Promote'); ?></button>
                                    </form>
                                </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')  ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status')  )]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

            </div>

            <div class="tab-pane active" id="tab2">
                <div class="row">
                <?php $__currentLoopData = $class->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-3">
                    <div class="thumbnail object-contain col-12 col-md">
                    <?php if($student->profile_pic_filepath): ?>
                        <img src="<?php echo e(asset('storage/' . $student->profile_pic_filepath)); ?>" alt="Profile Image" class="rounded-md mr-2 w-full">
                    <?php else: ?>
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'w-20 h-20 fill-current text-gray-500','width' => __('100%')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-20 h-20 fill-current text-gray-500','width' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('100%'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    <?php endif; ?>
                    </div>
                    <div class="caption">
                        <h3> <?php echo e($student->name); ?> </h3>
                        <p></p>
                        <p>
                            <a href="<?php echo e(route('student.edit')); ?>?id=<?php echo e($student->id); ?>" class="btn btn-primary" role="button">
                            Edit
                            </a>
                            <a href="<?php echo e(route('student.show', ['id' => $student->id])); ?>" class="btn btn-default" role="button">
                            View
                            </a>
                            <div class="btn-group">
                                <button class="btn btn-danger">Report Card</button>
                                <button class="btn btn-danger dropdown-toggle" data-toggle="dropdown">
                                <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu">
                                    <?php $__currentLoopData = $student->periods(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('reportcard', ['pid' => $period->id, 'sid' => $student->id])); ?>"><?php echo e($period->name); ?> - <?php echo e($period->value(DB::raw('YEAR(date_from)'))); ?> </a></li>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>


            <div class="tab-pane" id="tab3">
                <div class="row">
                <table class="table table-striped col-12">
                    <h4 align='center' class="text-info">Requirements</h4>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>quantity</th>
                        <th>price</th>
                        <th>Compulsary</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $requirements = $class->requirements()->where('name', '!=', 'schoolfees')->where('period_id', session('period_id'))->get(); ?>
                    <?php if($requirements && count($requirements) > 0 ): ?>
                        <?php $__currentLoopData = $requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($item->name); ?></th>
                            <td><?php echo e($item->quantity === 0 ? '-' : $item->quantity); ?></td>
                            <td><?php echo e($item->price  === null ? '-' : $item->price); ?></td>
                            <td><?php echo e($item->compulsary === 'y' ? 'Yes' : 'No'); ?></td>
                            <td><a href="<?php echo e(route('requirements.edit', ['id' => $item->id])); ?>"><i class="icon-edit"><button class="btn btn-info">Edit</button></i></a></td>
                            <td>
                                <form action="<?php echo e(route('requirements.delete', ['id' => $item->id])); ?>" method="post" onsubmit=" !confirm('Are you sure?') ? event.preventDefault() : '' ">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <i class="icon-edit"><button class="btn btn-danger">Delete</button></i>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <h4 align='center' class="text-error">No requirements yet</h4>
                    <?php endif; ?>
                </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/todo-app/resources/views/class/details.blade.php ENDPATH**/ ?>