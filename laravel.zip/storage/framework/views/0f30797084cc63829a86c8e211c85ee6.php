<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div class="tabbable tabs-left">
    <ul class="nav nav-tabs" style="display: flex; justify-content: space-between">
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="#tab<?php echo e($subject->id); ?>" data-toggle="tab"><button type="button" class="btn btn-primary" style="background-color: deepskyblue"> <?php echo e($subject->name); ?> </button></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <div class="tab-content">
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="tab-pane" id="tab<?php echo e($subject->id); ?>">

            <form method="POST" action="<?php echo e(route('marks.resolve-storage')); ?>" class="dark:text-gray-300">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="class_id" value="<?php echo e($clas->id); ?>">
                <input type="hidden" name="subject_id" value="<?php echo e($subject->id); ?>">

        <table class="table table-hover table-striped" >
            <h2 align="center"><?php echo e($subject->name); ?> :  <?php echo e($clas->name); ?> </h2>
            <thead>
                <tr>
                    <th></th>
                    <th>Name</th>
                    <th>Mid term</th>
                    <th>End of term</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <img src="<?php echo e(asset('storage/' . $student->profile_pic_filepath)); ?>" alt="Profile Image" width="30" class="rounded-md mr-2"></td>
                    <td> <?php echo e($student->name); ?></td>
                    <input type="hidden" name="students[]" value="<?php echo e($student->id); ?>">
                    <td><input type="number" name="marks_mid[]" id="mid<?php echo e($student->id); ?>" value="<?php echo e($m = $student->marks()->where('subject_id', $subject->id)->where('period_id', session('period_id'))->where('type', 'mid')->first() ? $student->marks()->where('subject_id', $subject->id)->where('period_id', session('period_id'))->where('type', 'mid')->first()->mark : 0); ?>" class="border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm" min="0" max="100"></td>
                    <td><input type="number" name="marks_end[]" id="end<?php echo e($student->id); ?>" value="<?php echo e($m = $student->marks()->where('subject_id', $subject->id)->where('period_id', session('period_id'))->where('type', 'end')->first() ? $student->marks()->where('subject_id', $subject->id)->where('period_id', session('period_id'))->where('type', 'end')->first()->mark : 0); ?>" class="border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm" min="0" max="100"></td>
                    <td> <i class="icon-eye-open"></i></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>

                <div>
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'ml-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ml-4']); ?>
                        <?php echo e(__('Set')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
            </form>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<!--
     I have to implement forms where each nav tab is a subject, then the section is a
    form containing student's names and their marks to be filled, then a hidden form field
    for subject_id and class_id. The server will then attach the period_id according to the
    current session's period_id. And the type of exam(mid, end, bot) to be stored to the db
-->

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/todo-app/resources/views/marks/create.blade.php ENDPATH**/ ?>