<!DOCTYPE html>
<html>
<head>
	<title>Seeta C.o.U Primary School</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <style>

        @media print {
          .dont-print {
            display: none;
          }
        }
    </style>

</head>
<body class="">
	<nav class="navbar navbar-expand-lg bg-gray-300 z-50 backdrop-blur">
		<a class="navbar-brand" href="#">Seeta C.o.U Primary School
            <button onclick="window.print()" class="dont-print btn btn-info">Print page</button>
        </a><!--
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>-->
		<!--<div class="collape navbar-collae" id="navbarNav">-->
			<ul class="navbar-nav m-auto flex-row justify-between">
				<li class="nav-item active">
					<a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Home</a>
				</li>
                <?php if(count(Auth::user()->classes) > 0 && count(Auth::user()->subjects) > 0): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false" href="#" id="marksheetDropdown">Create Marksheet</a>
                        <div class="dropdown-menu"  aria-labelledby="marksheetDropdown">
                            <?php $__currentLoopData = Auth::user()->classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="dropdown-item" href=" <?php echo e(route('marksheet', ['class_id' => $class->id])); ?>"> <?php echo e($class->name); ?> </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </li>
                <?php endif; ?>
				<li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false" href="#" id="academiaDropdown">Academia</a>
                    <div class="dropdown-menu"  aria-labelledby="academiaDropdown">
                        <?php if(Auth::user()->class): ?>
                            <a class="dropdown-item" href="<?php echo e(route('grading')); ?>">Aggregation</a>
                            <a class="dropdown-item" href="<?php echo e(route('comments')); ?>">Commenting</a>
                            <a class="dropdown-item" href="<?php echo e(route('attendance.create', ['class_id' => Auth::user()->class->id])); ?>">Attendance</a>
                        <?php endif; ?>
                        <?php if(in_array(Auth::user()->role, ['dos', 'secretary', 'head_teacher'])): ?>
                            <a class="dropdown-item" href="<?php echo e(route('period')); ?>">Set Year Calendar</a>
                        <?php endif; ?>
					</div>
				</li>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						Register
					</a>
					<div class="dropdown-menu" aria-labelledby="navbarDropdown">
						<?php if(in_array(Auth::user()->role, ['admini'])): ?>
						    <a class="dropdown-item" href="<?php echo e(route('register')); ?>">Staff</a>
						<?php endif; ?>
                            <a class="dropdown-item" href="<?php echo e(route('student.create')); ?>">Student</a>
                            <a class="dropdown-item" href="<?php echo e(route('class-reg')); ?>">Class</a>
                            <a class="dropdown-item" href="<?php echo e(route('subject-reg')); ?>">Subject</a>
						<div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('parent')); ?>">Parent</a>
                            <a class="dropdown-item" href="<?php echo e(route('requirements.create')); ?>">Requirements</a>
					</div>
				</li>
			<!--</ul>-->

			<!--<ul class="navbar-nav ml-auto ">-->
                <!--<li class="nav-item unshow-on-small-screen" style=""><span class="badge badge-info"><?php echo e(str_replace('-', '/', session('today'))); ?></span></li>-->
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle unshow-on-small-screen" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <?php if(Auth::user()->profile_pic_filepath): ?>
						    <img src="<?php echo e(asset('storage/' . Auth::user()->profile_pic_filepath)); ?>" alt="Profile Image" width="30" class="rounded-circle mr-2">
                        <?php else: ?>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['width' => __('20px')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['width' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('20px'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        <?php endif; ?>
					</a>
					<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
						<a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">My Profile</a>
						<form action="<?php echo e(route('logout')); ?>" method="POST" class="dropdown-item">
							<?php echo csrf_field(); ?>
							<input type="submit" value="Logout">
						</form>
					</div>
				</li>
			</ul>

	</nav>

	<!-- Page Content -->
	<div class="dark:text-gray-300 dark:border-gray-300" >
            <?php echo $__env->yieldContent('content'); ?>
	</div>

	<!-- Include jQuery and Bootstrap JS -->
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/todo-app/resources/views/layouts/app.blade.php ENDPATH**/ ?>