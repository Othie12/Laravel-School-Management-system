<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
    <form method="POST" action="<?php echo e(route('comments.update')); ?>" class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>

<table class="table table-hover table-striped" >
    <h2>SET COMMENTS</h2>
    <tr>
        <th>Percentile</th>
        <th>Classteacher's Comment</th>
        <th>Headteacher's Comment</th>
    </tr>
<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>
            <?php switch($comment->agg_from):
                case (0): ?>
                First
                    <?php break; ?>
                <?php case (10): ?>
                Second
                    <?php break; ?>
                <?php case (20): ?>
                Third
                    <?php break; ?>
                <?php case (30): ?>
                Fourth
                    <?php break; ?>
                <?php case (40): ?>
                Fifth
                    <?php break; ?>
                <?php case (50): ?>
                Sixth
                    <?php break; ?>
                <?php case (60): ?>
                Seventh
                    <?php break; ?>
                <?php case (70): ?>
                Eigth
                    <?php break; ?>
                <?php case (80): ?>
                Nineth
                    <?php break; ?>
                <?php case (90): ?>
                Tenth
                    <?php break; ?>
                <?php default: ?>
                --Error--
            <?php endswitch; ?>
            </td>
            <input type="hidden" name="ids[]" value="<?php echo e($comment->id); ?>">
        <td><textarea name="ctcomms[]" id="" cols="30" rows="1" class="border-gray-300 dark:border-gray-300 dark:bg-gray dark:text-gray-300 dark:bg-gray-700 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm" required ><?php echo e($comment->ct_comm); ?></textarea></td>
        <td><textarea <?php echo e(Auth::user()->role === 'head_teacher' ? 'required' : 'disabled'); ?> name="htcomms[]" id="" cols="30" rows="1" class="border-gray-300 dark:border-gray-300 dark:bg-gray-700 dark:text-gray-300 dark:bg-black-600 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm" ><?php echo e($comment->ht_comm); ?></textarea></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

        <div>
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'ml-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ml-4']); ?>
                <?php echo e(__('Set')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </div>
    </form>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/todo-app/resources/views/comments/edit.blade.php ENDPATH**/ ?>