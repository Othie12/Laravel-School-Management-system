<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['width' => '100', 'height' => '100']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['width' => '100', 'height' => '100']); ?>
<?php foreach (array_filter((['width' => '100', 'height' => '100']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<img src="<?php echo e(asset('storage/logos/Asset 8.png')); ?>" alt="Profile Image" width="<?php echo e($width); ?>" height="<?php echo e($height); ?>" class="rounded-md mr-2">
<?php /**PATH /opt/lampp/htdocs/todo-app/resources/views/components/application-logo.blade.php ENDPATH**/ ?>