<a href="<?php echo e($href); ?>" <?php echo e($attributes->merge(['class' => 'btn btn-link'])); ?>>
    <?php echo e($slot); ?>

</a>


<?php /**PATH /opt/lampp/htdocs/todo-app/resources/views/components/button-link.blade.php ENDPATH**/ ?>