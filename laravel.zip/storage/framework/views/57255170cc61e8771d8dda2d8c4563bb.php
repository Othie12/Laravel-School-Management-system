    <?php $__env->startSection('content'); ?>
        <div align="center" class="mt-4 dark:bg-gray-700 items-center md:justify-center dark:text-gray-300">
            <a href="<?php echo e('storage/' . $student->profile_pic_filepath); ?>" align="center"><img src="<?php echo e(asset('storage/' . $student->profile_pic_filepath)); ?>" alt="Profile Image" width="100" class="rounded-md mr-2"></a>
        </div>
            <table class="table mt-4 dark:text-gray-300" style="background-image: url("<?php echo e('storage/' . $student->profile_pic_filepath); ?>");">
                <tr>
                    <th>Name: </th>
                    <td><?php echo e($student->name); ?></td>
                </tr>
                <tr>
                    <th>Sex: </th>
                    <td><?php echo e($student->sex === 'm' ? 'Male' : 'Female'); ?></td>
                </tr>
                <tr>
                    <th>D.O.B: </th>
                    <td><?php echo e($student->dob); ?></td>
                </tr>
                <tr>
                    <th>Class: </th>
                    <td><?php echo e($student->class->name); ?></td>
                </tr>
                <tr>
                    <th>
                        <div class="btn-group">
                            <button class="btn btn-danger">Report Card</button>
                            <button class="btn btn-danger dropdown-toggle" data-toggle="dropdown">
                            <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu">
                                <?php $__currentLoopData = $student->periods(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('reportcard', ['pid' => $period->id, 'sid' => $student->id])); ?>"><?php echo e($period->name); ?> - <?php echo e($period->value(DB::raw('YEAR(date_from)'))); ?> </a></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </th>
                </tr>
            </table>
    </section>
<?php $__env->stopSection(); ?>

<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/todo-app/resources/views/student/show.blade.php ENDPATH**/ ?>